import 'package:flutter/material.dart';

/// Model data menu. Status [tersedia] memakai ValueNotifier sehingga
/// perubahan status hanya me-rebuild SATU kartu, bukan seluruh daftar.
class MenuItem {
  MenuItem({
    required this.id,
    required this.nama,
    required this.harga,
    required this.icon,
    bool tersedia = true,
  }) : tersedia = ValueNotifier<bool>(tersedia);

  final int id;
  final String nama;
  final int harga;
  final IconData icon;
  final ValueNotifier<bool> tersedia;

  String get heroTag => 'ikon-menu-$id';

  static List<MenuItem> contoh() => [
        MenuItem(id: 1, nama: 'Kopi Susu', harga: 18000, icon: Icons.coffee),
        MenuItem(id: 2, nama: 'Americano', harga: 20000, icon: Icons.coffee_maker),
        MenuItem(id: 3, nama: 'Cafe Latte', harga: 25000, icon: Icons.local_cafe),
        MenuItem(id: 4, nama: 'Teh Tarik', harga: 15000, icon: Icons.emoji_food_beverage),
        MenuItem(id: 5, nama: 'Roti Bakar', harga: 17000, icon: Icons.bakery_dining),
        MenuItem(id: 6, nama: 'Nasi Goreng', harga: 28000, icon: Icons.rice_bowl),
        MenuItem(id: 7, nama: 'Mie Goreng', harga: 26000, icon: Icons.ramen_dining),
        MenuItem(id: 8, nama: 'Burger', harga: 32000, icon: Icons.lunch_dining),
        MenuItem(id: 9, nama: 'Es Krim', harga: 12000, icon: Icons.icecream),
        MenuItem(id: 10, nama: 'Cookies', harga: 10000, icon: Icons.cookie),
      ];
}

String formatRupiah(int v) {
  final s = v.toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write('.');
    b.write(s[i]);
  }
  return 'Rp $b';
}

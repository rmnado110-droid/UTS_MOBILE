import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Ikon cangkir berputar terus-menerus (0 .. 2π).
class RotatingCup extends StatefulWidget {
  const RotatingCup({super.key});

  @override
  State<RotatingCup> createState() => _RotatingCupState();
}

class _RotatingCupState extends State<RotatingCup>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 3),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose(); // wajib: hindari kebocoran ticker
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // RepaintBoundary: animasi dicat di layer sendiri, sisa layar tidak ikut repaint.
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _controller,
        // child const: dibangun sekali, tidak ikut rebuild tiap frame.
        child: const Icon(Icons.coffee, size: 40, color: Colors.white),
        builder: (context, child) {
          return Transform.rotate(
            angle: _controller.value * 2 * math.pi,
            child: child,
          );
        },
      ),
    );
  }
}

import 'package:flutter/material.dart';

import 'hero_utils.dart';
import 'menu_item.dart';

class DetailPage extends StatelessWidget {
  const DetailPage({super.key, required this.menu});

  final MenuItem menu;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F0),
      appBar: AppBar(
        title: Text(menu.nama),
        backgroundColor: kWarnaIkon,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Column(
            children: [
              const SizedBox(height: 16),
              // Tujuan hero: persegi besar, sudut membulat.
              Hero(
                tag: menu.heroTag,
                createRectTween: radialRectTween,
                flightShuttleBuilder: radialShuttle(menu.icon),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(kRadiusAkhir),
                  child: Container(
                    width: 220,
                    height: 220,
                    color: kWarnaIkon,
                    child: Icon(menu.icon, size: 110, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                menu.nama,
                style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                formatRupiah(menu.harga),
                style: const TextStyle(fontSize: 20, color: Color(0xFF5D4037)),
              ),
              const SizedBox(height: 16),
              ValueListenableBuilder<bool>(
                valueListenable: menu.tersedia,
                builder: (context, ada, _) => Chip(
                  label: Text(ada ? 'Tersedia' : 'Habis'),
                  backgroundColor:
                      ada ? const Color(0xFFC8E6C9) : const Color(0xFFFFCDD2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

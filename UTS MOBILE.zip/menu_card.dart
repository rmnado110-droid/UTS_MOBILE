import 'package:flutter/material.dart';

import 'hero_utils.dart';
import 'menu_item.dart';

class MenuCard extends StatelessWidget {
  const MenuCard({
    super.key,
    required this.heroTag,
    required this.nama,
    required this.harga,
    required this.tersedia,
    required this.icon,
    required this.onTap,
    required this.onLongPress,
  });

  final String heroTag;
  final String nama;
  final int harga;
  final bool tersedia;
  final IconData icon;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  // Satu BoxDecoration: LinearGradient + borderRadius 20 + border + boxShadow.
  static const BoxDecoration _dekorasi = BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFFFFF3E0), Color(0xFFFFCC80)],
    ),
    borderRadius: BorderRadius.all(Radius.circular(20)),
    border: Border.fromBorderSide(
      BorderSide(color: Color(0xFF8D6E63), width: 1.5),
    ),
    boxShadow: [
      BoxShadow(
        color: Color(0x40000000),
        blurRadius: 10,
        offset: Offset(0, 4),
      ),
    ],
  );

  // Lingkaran ikon (BoxShape.circle).
  static const BoxDecoration _lingkaran = BoxDecoration(
    shape: BoxShape.circle,
    color: kWarnaIkon,
  );

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Stack(
        children: [
          // AnimatedOpacity (bukan widget Opacity). Saat tersedia = 1.0,
          // Flutter melukis child langsung tanpa saveLayer.
          AnimatedOpacity(
            opacity: tersedia ? 1.0 : 0.4,
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeInOut,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: _dekorasi,
              child: Row(
                children: [
                  Hero(
                    tag: heroTag,
                    createRectTween: radialRectTween,
                    flightShuttleBuilder: radialShuttle(icon),
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: _lingkaran,
                      child: Icon(icon, color: Colors.white, size: 28),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          nama,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF3E2723),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          formatRupiah(harga),
                          style: const TextStyle(
                            fontSize: 15,
                            color: Color(0xFF5D4037),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (!tersedia)
            const Positioned(
              top: 10,
              right: 12,
              child: _LabelHabis(),
            ),
        ],
      ),
    );
  }
}

class _LabelHabis extends StatelessWidget {
  const _LabelHabis();

  @override
  Widget build(BuildContext context) {
    return const DecoratedBox(
      decoration: BoxDecoration(
        color: Color(0xFFC62828),
        borderRadius: BorderRadius.all(Radius.circular(8)),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        child: Text(
          'Habis',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
      ),
    );
  }
}

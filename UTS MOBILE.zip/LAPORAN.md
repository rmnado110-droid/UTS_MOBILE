# Laporan UTS Praktik – Katalog Menu (Flutter)

Nama : ________   NIM : ________
GitHub : ________   YouTube : ________

## 1. Pemetaan Butir Soal → Kode
| Butir | Implementasi | Berkas |
|---|---|---|
| 1 BoxDecoration | `MenuCard._dekorasi`: LinearGradient, borderRadius 20, border, boxShadow; ikon di `BoxShape.circle` | `menu_card.dart` |
| 2 Opacity | Long press membalik `tersedia`; `AnimatedOpacity` 0.4, 400 ms + label "Habis" | `menu_card.dart`, `katalog_page.dart` |
| 3 Daftar | `ListView.builder` 10 menu; tidak ada widget `Opacity` | `katalog_page.dart` |
| 4 Radial hero | `Hero` + `MaterialRectCenterArcTween` + `ClipRRect` radius diinterpolasi (setengah sisi → 28), 600 ms | `hero_utils.dart`, `detail_page.dart` |
| 5 Radial berputar | `AnimationController.repeat()`, `Transform.rotate` 0..2π, `AnimatedBuilder(child:)`, `RepaintBoundary`, `dispose()` | `rotating_cup.dart` |
| 6 const | Dekorasi, label, header, padding, `SizedBox`, `TextStyle`, ikon cangkir | semua berkas |
| 7 Laporan | bagian 3 di bawah | – |

## 2. Teknik Optimasi
- `ValueNotifier` per menu + `ValueListenableBuilder` per item → long press hanya rebuild 1 kartu (bukan `setState` seluruh halaman).
- `AnimatedBuilder` memakai parameter `child` (const) → ikon tidak dibangun ulang tiap frame.
- `RepaintBoundary` → animasi cangkir tidak memicu repaint bagian lain.
- `AnimatedOpacity` bernilai 1.0 saat tersedia → Flutter melukis anak langsung tanpa `saveLayer`.
- `ListView.builder` → hanya item terlihat yang dibangun.

## 3. Pengukuran DevTools (Profile Mode)
Jalankan di perangkat fisik (bukan emulator/debug):
```
flutter run --profile
```
Buka DevTools → **Performance** (centang *Track widget builds*) dan **Flutter Frames**.
Skenario uji (sama untuk sebelum & sesudah): scroll cepat naik-turun 10 detik, long press 5 kartu bergantian, buka-tutup DetailPage 3×.

**Versi "Sebelum"** (buat branch `sebelum`): hapus `RepaintBoundary`, hapus `child:` pada AnimatedBuilder (ikon dibuat di builder), hapus semua `const`, dan ubah status menu memakai `setState` di `KatalogPage` (tanpa ValueListenableBuilder).

| Metrik | Sebelum | Sesudah |
|---|---|---|
| Rata-rata waktu frame UI (ms) | | |
| Rata-rata waktu frame Raster (ms) | | |
| Jumlah frame jank (>16 ms) | | |
| Widget rebuild saat long press (Rebuild Stats) | | |
| Repaint header saat list di-scroll | | |

**Analisis singkat (isi sesuai angka hasil ukur):**
Pada versi sebelum, long press memicu rebuild seluruh daftar dan animasi cangkir ikut me-repaint layer lain. Setelah optimasi, rebuild terbatas pada satu kartu, ikon cangkir dibangun sekali, dan header memiliki layer cacah sendiri sehingga waktu frame lebih stabil dan jumlah frame jank berkurang. Lampirkan tangkapan layar timeline DevTools kedua versi.

## 4. Naskah Video (5–10 menit)
1. (0:30) Perkenalan nama/NIM, tujuan aplikasi.
2. (2:00) Demo: header berputar, scroll 10 menu, long press → pudar 0.4 + label "Habis", long press lagi → pulih, tap → hero radial ke DetailPage dan kembali.
3. (3:00) Penjelasan kode: BoxDecoration, AnimatedOpacity, Hero + createRectTween + ClipRRect, AnimationController + dispose, RepaintBoundary, const.
4. (2:00) Tampilkan DevTools profile mode sebelum vs sesudah dan simpulkan.
5. (0:30) Penutup. Jika berkelompok, semua anggota tampil.

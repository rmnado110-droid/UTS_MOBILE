import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';

/// Durasi transisi halaman + hero (soal: 600 ms).
const Duration kDurasiHero = Duration(milliseconds: 600);

const Color kWarnaIkon = Color(0xFF6D4C41);
const double kRadiusAkhir = 28;

/// Lintasan melengkung (arc) untuk hero, bukan garis lurus.
RectTween radialRectTween(Rect? begin, Rect? end) =>
    MaterialRectCenterArcTween(begin: begin, end: end);

/// Shuttle: lingkaran -> persegi besar dengan radius yang diinterpolasi.
/// Radius awal = setengah sisi (lingkaran sempurna), radius akhir = [kRadiusAkhir].
HeroFlightShuttleBuilder radialShuttle(IconData icon) {
  return (flightContext, animation, direction, fromContext, toContext) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, _) {
        final t = Curves.easeInOut.transform(animation.value);
        return LayoutBuilder(
          builder: (context, c) {
            final sisi = c.biggest.shortestSide;
            final radius = lerpDouble(sisi / 2, kRadiusAkhir, t)!;
            return ClipRRect(
              borderRadius: BorderRadius.circular(radius),
              child: ColoredBox(
                color: kWarnaIkon,
                child: Center(
                  child: Icon(icon, size: sisi * 0.5, color: Colors.white),
                ),
              ),
            );
          },
        );
      },
    );
  };
}

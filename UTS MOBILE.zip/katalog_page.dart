import 'package:flutter/material.dart';

import 'detail_page.dart';
import 'hero_utils.dart';
import 'menu_card.dart';
import 'menu_item.dart';
import 'rotating_cup.dart';

class KatalogPage extends StatefulWidget {
  const KatalogPage({super.key});

  @override
  State<KatalogPage> createState() => _KatalogPageState();
}

class _KatalogPageState extends State<KatalogPage> {
  final List<MenuItem> _menus = MenuItem.contoh(); // 10 menu

  @override
  void dispose() {
    for (final m in _menus) {
      m.tersedia.dispose();
    }
    super.dispose();
  }

  void _bukaDetail(MenuItem menu) {
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        transitionDuration: kDurasiHero,
        reverseTransitionDuration: kDurasiHero,
        pageBuilder: (_, __, ___) => DetailPage(menu: menu),
        transitionsBuilder: (_, animation, __, child) =>
            FadeTransition(opacity: animation, child: child),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F0),
      body: SafeArea(
        child: Column(
          children: [
            const _KatalogHeader(),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _menus.length,
                itemBuilder: (context, i) {
                  final menu = _menus[i];
                  // Hanya kartu ini yang rebuild saat status berubah.
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: ValueListenableBuilder<bool>(
                      valueListenable: menu.tersedia,
                      builder: (context, ada, _) => MenuCard(
                        heroTag: menu.heroTag,
                        nama: menu.nama,
                        harga: menu.harga,
                        tersedia: ada,
                        icon: menu.icon,
                        onTap: () => _bukaDetail(menu),
                        onLongPress: () => menu.tersedia.value = !ada,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _KatalogHeader extends StatelessWidget {
  const _KatalogHeader();

  @override
  Widget build(BuildContext context) {
    return const ColoredBox(
      color: kWarnaIkon,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Row(
          children: [
            RotatingCup(),
            SizedBox(width: 14),
            Text(
              'Katalog Menu',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
